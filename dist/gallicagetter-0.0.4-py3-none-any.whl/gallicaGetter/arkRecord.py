class ArkRecord:

    def __init__(self, code, years):
        self.code = code
        self.years = years